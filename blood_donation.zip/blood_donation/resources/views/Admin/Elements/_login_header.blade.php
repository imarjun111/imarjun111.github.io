  <header>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <strong>Email: </strong>info@bloodDonation.com
                    &nbsp;&nbsp;
                    <strong>Support: </strong>+90-897-678-44
                </div>

            </div>
        </div>
    </header>
    <!-- HEADER END-->
    <div class="navbar navbar-inverse set-radius-zero ">
        <div class="container">
            <div class="navbar-header left-div">
               {{--  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button> --}}
                <a class="navbar-brand" href="{{ url('/home') }}">

                    <img src="{{ URL::asset('public/img/logo.png') }}" />
                </a>

            </div>

        
            </div>
        </div>
    <!-- LOGO HEADER END-->