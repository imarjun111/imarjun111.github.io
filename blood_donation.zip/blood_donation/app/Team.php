<?php

namespace App;

//use Illuminate\Database\Eloquent\Model;
use Laratrust\Models\LaratrustTeam;

class Team extends LaratrustTeam
{
    //
}
