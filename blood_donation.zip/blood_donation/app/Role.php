<?php

namespace App;

//use Illuminate\Database\Eloquent\Model;

use Laratrust\Models\LaratrustRole;

class Role extends LaratrustRole
{
    //
}
