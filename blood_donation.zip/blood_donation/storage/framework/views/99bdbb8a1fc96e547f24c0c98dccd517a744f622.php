     <footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2018 Devoy Softech PVT. LTD. | By : <a href="http://www.devoysoftech.com/" target="_blank">DevoySoftech</a>
                </div>

            </div>
    </footer>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="<?php echo e(URL::asset('public/js/jquery-1.11.1.js')); ?>"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="<?php echo e(URL::asset('public/js/bootstrap.js')); ?>"></script>