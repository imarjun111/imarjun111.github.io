<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php echo $__env->make('Admin.Elements._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
</head>
<body>
   <!-- menu section-->
<?php echo $__env->make('Admin.Elements._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
   <!-- end menu section-->
<div class="content-wrapper">
    <?php echo $__env->yieldContent('content'); ?>
</div>
     <!--footer-->
 <?php echo $__env->make('Admin.Elements._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <!--end footer-->
</body>
</html>
