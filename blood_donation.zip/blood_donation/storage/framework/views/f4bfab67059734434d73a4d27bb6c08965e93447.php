 
<?php $__env->startSection('title','| Add User'); ?>
<?php $__env->startSection('content'); ?>   
    <div class="container">
              <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-head-line">Add User </h1>
                    </div>
                </div>
                 <!-- flash maessage-->
                <div class="flash-message">
                       <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php if(Session::has('alert-' . $msg)): ?>

                           <p class="alert alert-<?php echo e($msg); ?>"><?php echo e(Session::get('alert-' . $msg)); ?>

                            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                           </p>
                         <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div> 

                  <!--flash message end-->
               <?php echo Form::open(['url'=>'admin/users/addUser','enctype'=>'multipart/form-data']); ?>

                <div class="row">
                    <div class="col-md-12">
                        <div class="panel panel-default">
                        <div class="panel-heading">
                            <div class="row">
                           <div class="col-md-6"> User Detail</div>
                           <div class="col-md-6">
                            <span class="pull-right"> 
                              <?php echo Form::submit('Save',['class'=>'btn btn-success']); ?>

                            <a href="<?php echo e(url('admin/users')); ?>" class="btn btn-danger">Cancel</a>
                           </div>
                         </div>
                        </div>
                        <div class="panel-body">
                                            
                        
                         <div class="form-group">
                          <?php echo Form::label('name'); ?>

                          
                          <?php echo Form::text('name','',['class'=>'form-control','placeholder'=>'Enter Name']); ?>

                          <?php echo($errors->first('name',"<li class='error' style='color:red;list-style-type:none;'>:message</li>") ); ?>
                        </div>
                          
                       <div class="form-group">
                          <?php echo Form::label('email'); ?>

                          
                          <?php echo Form::text('email','',['class'=>'form-control','placeholder'=>'Enter Email']); ?>

                            <?php echo($errors->first('email',"<li class='error' style='color:red;list-style-type:none;'>:message</li>")); ?>
                        </div>

                        <div class="form-group">
                          <?php echo Form::label('mobile'); ?>

                          
                          <?php echo Form::text('mobile','',['class'=>'form-control','placeholder'=>'Enter phone number']); ?>

                        </div>
                        <div class="form-group">
                          <?php echo Form::label('password'); ?>

                          
                          <?php echo Form::password('password',['class'=>'form-control','placeholder'=>'Enter password']); ?>

                        </div>

                          <div class="form-group">
                          <?php echo Form::label('File'); ?>

                          
                          <?php echo Form::file('image',['class'=>'form-control','placeholder'=>'select image']); ?>

                        </div>
                       
                        
                        
                            </div>
                            </div>
                    </div>
                    
                </div>
              <?php echo Form::close(); ?>

        </div>
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>