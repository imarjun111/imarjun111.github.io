<?php if(!app('mobile-detect')->isMobile()) : ?> 
	<h1>Desktop view</h1>
<?php else: ?>
	<h1>Mobile view</h1>
<?php endif; ?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php echo $__env->make('Admin.Elements._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   
</head>
<body>
   <!-- menu section-->
<?php echo $__env->make('Admin.Elements._login_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
   <!-- end menu section-->
<div class="content-wrapper">
    <?php echo $__env->yieldContent('content'); ?>
</div>
     <!--footer-->
 <?php echo $__env->make('Admin.Elements._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
     <!--end footer-->
</body>
</html>
